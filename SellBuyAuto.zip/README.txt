Pour lancer l'application, il suffit d'exécuter SellBuyAuto.application. Il va automatiquement faire appel au setup.exe
et installer ce dont il a besoin.

Afin de tester la fonction de login et ainsi avoir accès à plus de fonctionnalité, 
voici tous les comptes créer jusqu’à maintenant :

     Email              |       Username	|	Mot de passe

utilisateur1@example.com	JohnDoe			Pa$$w0rd
utilisateur2@example.com	AliceSmith		Pa$$w0rd
utilisateur3@example.com	DavidBrown		Pa$$w0rd
utilisateur4@example.com	EmilyJohnson		Pa$$w0rd
utilisateur5@example.com	MichaelWilliams		Pa$$w0rd
utilisateur6@example.com	SarahWilson		Pa$$w0rd
utilisateur7@example.com	JamesTaylor		Pa$$w0rd
utilisateur8@example.com	EmmaMartinez		Pa$$w0rd
utilisateur9@example.com	DanielJones		Pa$$w0rd
utilisateur10@example.com	OliviaBrown		Pa$$w0rd
utilisateur11@example.com	MatthewThomas		Pa$$w0rd
utilisateur12@example.com	AvaGarcia		Pa$$w0rd
utilisateur13@example.com	WilliamRodriguez	Pa$$w0rd
utilisateur14@example.com	SophiaLopez		Pa$$w0rd
utilisateur15@example.com	JosephLee		Pa$$w0rd
utilisateur16@example.com	Dragtsu			Pa$$w0rd
admin@example.com		Admin			Pa$$w0rd